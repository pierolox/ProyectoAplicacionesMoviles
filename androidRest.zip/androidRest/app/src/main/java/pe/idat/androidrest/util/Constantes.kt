package pe.idat.androidrest.util

class Constantes {
    companion object {
        val URL_BASE_API = "http://10.0.2.2:8080/WebApplication1/"
    }
}