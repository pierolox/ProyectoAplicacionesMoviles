package pe.idat.androidrest.retrofit.request

data class RegistroRequest (
    val nombre: String,
    val correo: String,
    val contrasena: String
)