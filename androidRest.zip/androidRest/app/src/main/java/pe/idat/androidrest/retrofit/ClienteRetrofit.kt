package pe.idat.androidrest.retrofit

import pe.idat.androidrest.retrofit.api.ClienteRest
import pe.idat.androidrest.util.Constantes
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

object ClienteRetrofit {

    val api: ClienteRest by lazy {
        Retrofit.Builder()
            .baseUrl(Constantes.URL_BASE_API)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(ClienteRest::class.java)
    }
}