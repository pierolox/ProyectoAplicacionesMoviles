package pe.idat.androidrest.retrofit.api

import pe.idat.androidrest.retrofit.request.LoginRequest
import pe.idat.androidrest.retrofit.request.RegistroRequest
import pe.idat.androidrest.retrofit.response.LoginResponse
import retrofit2.Call
import retrofit2.http.Body
import retrofit2.http.POST

interface ClienteRest {
    @POST("usuario/login")
    fun login(@Body request: LoginRequest): Call<LoginResponse>

    @POST("usuario/registrar")
    fun registrar(@Body request: RegistroRequest): Call<String>
}