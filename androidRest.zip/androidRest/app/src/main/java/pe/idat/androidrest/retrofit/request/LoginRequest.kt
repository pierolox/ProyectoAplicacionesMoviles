package pe.idat.androidrest.retrofit.request

data class LoginRequest(
    val correo: String,
    val contrasena: String
)
