package pe.idat.androidrest.util

enum class TipoMensaje {
    ERROR, SUCCESS, WARNING, INFO
}