package pe.idat.androidrest.retrofit.response

data class LoginResponse(
    val id: Int,
    val nombre: String,
    val correo: String,
    val contrasena: String
)
